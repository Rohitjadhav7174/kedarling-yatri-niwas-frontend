import { BrowserRouter, Routes, Route } from "react-router-dom";
import Home from "./Pages/Home/Home";
import About from "./Pages/AboutUs/About";

function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} exact /> {/* Home Page */}
        <Route path="/about-us" element={<About />} exact /> {/* About Us Page */}
        {/* Add other pages using kebab-case URLs */}
      </Routes>
    </BrowserRouter>
  );
}

export default App;
