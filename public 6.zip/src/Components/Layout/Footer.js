import React from "react";
import { Box, Grid, Typography, Button, List, ListItem, ListItemText, IconButton } from "@mui/material";
import { Facebook, Instagram, TripOrigin } from "@mui/icons-material";

const Footer = () => {
  return (
    <Box sx={{ bgcolor: "#1a1a1a", color: "white", p: 4 }}>
      <Grid container spacing={4}>
        {/* Logo and Booking */}
        <Grid item xs={12} sm={6} md={3}>
          <img
            src="https://planethollywoodthane.com/wp-content/uploads/2023/05/PH-Thane-City-purple-PNG-1White.png"
            alt="Logo"
            style={{ width: "100%", maxWidth: 200 }}
          />
          <Button variant="contained" color="secondary" sx={{ mt: 2 }}>
            Book Now
          </Button>
        </Grid>
        {/* Explore */}
        <Grid item xs={12} sm={6} md={3}>
          <Typography variant="h6">EXPLORE</Typography>
          <List>
            {["Home", "About Us", "Accommodation", "Dining & Events", "Contact", "Blogs"].map((text, index) => (
              <ListItem key={index} component="a" href="#" button>
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
        </Grid>
        {/* About */}
        <Grid item xs={12} sm={6} md={3}>
          <Typography variant="h6">About</Typography>
          <List>
            {["Gallery", "Privacy Policy", "Our Services", "Terms and Conditions", "Restaurant"].map((text, index) => (
              <ListItem key={index} component="a" href="#" button>
                <ListItemText primary={text} />
              </ListItem>
            ))}
          </List>
        </Grid>
        {/* Contact */}
        <Grid item xs={12} sm={6} md={3}>
          <Typography variant="h6">Contact Us</Typography>
          <List>
            <ListItem button component="a" href="tel:02268221000">
              <ListItemText primary="Landline: +91-22 68221000" />
            </ListItem>
            <ListItem button component="a" href="tel:+918806751000">
              <ListItemText primary="Emergency: +91 88067 51000" />
            </ListItem>
          </List>
          <Box sx={{ display: "flex", gap: 1, mt: 2 }}>
            <IconButton color="inherit" href="https://www.instagram.com/planethollywoodthane/" target="_blank">
              <Instagram />
            </IconButton>
            <IconButton color="inherit" href="https://www.facebook.com/planethollywoodthane" target="_blank">
              <Facebook />
            </IconButton>
            <IconButton color="inherit" href="https://www.tripadvisor.in/Hotel_Review-g660976-d24086926-Reviews-Planet_Hollywood_Thane_City-Thane_Thane_District_Maharashtra.html" target="_blank">
              <TripOrigin />
            </IconButton>
          </Box>
        </Grid>
      </Grid>
      {/* Footer Bottom */}
      <Box sx={{ mt: 4, textAlign: "center" }}>
        <Typography variant="body2">© All rights reserved 2024</Typography>
        <Typography variant="body2">Made with ❤ by Hashtag Media And Technology</Typography>
      </Box>
    </Box>
  );
};

export default Footer;
