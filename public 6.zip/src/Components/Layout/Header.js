import React, { useState } from 'react';
import { AppBar, Toolbar, Box, Button, IconButton, Menu, MenuItem, useMediaQuery, useTheme } from '@mui/material';
import MenuIcon from '@mui/icons-material/Menu';
import logo from '../../Assets/PH-Thane-City-purple-PNG-1White.png';

function Header() {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down('md'));
  const [anchorEl, setAnchorEl] = useState(null);

  const handleMenuOpen = (event) => {
    setAnchorEl(event.currentTarget);
  };

  const handleMenuClose = () => {
    setAnchorEl(null);
  };

  return (
    <AppBar position="static" color="primary">
      <Toolbar sx={{ display: "flex", justifyContent: "space-between" }}>
        <Box>
          <img src={logo} alt="Hotel Logo" width={150} height={30} />
        </Box>
        {!isMobile ? (
          <Box>
           {['Home', 'About Us', 'Contact', 'Gallery'].map((item) => (
  <Button key={item} href={`/${item.toLowerCase().replace(/\s+/g, '-')}`} color="">{item}</Button>
))}

          </Box>
        ) : (
          <IconButton color="inherit" onClick={handleMenuOpen}>
            <MenuIcon />
          </IconButton>
        )}
        <Menu anchorEl={anchorEl} open={Boolean(anchorEl)} onClose={handleMenuClose}>
          {['Home', 'About Us',  'Contact', 'Gallery'].map((item) => (
            <MenuItem key={item} onClick={handleMenuClose} component="a" href={`/${item.toLowerCase().replace(/\s+/g, '-')}/`}>
              {item}
            </MenuItem>
          ))}
        </Menu>
      </Toolbar>
    </AppBar>
  );
}

export default Header;