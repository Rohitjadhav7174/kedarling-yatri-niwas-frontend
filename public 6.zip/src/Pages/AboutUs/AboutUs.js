import React from "react";
import { Container, Grid, Typography, Box } from "@mui/material";

const AboutUs = () => {
  return (
    <Container maxWidth="md" sx={{ my: 4 }}>
      <Grid container spacing={4} alignItems="center">
        {/* Image Section */}
        <Grid item xs={12} md={6}>
          <Box component="img"
            src="https://planethollywoodthane.com/wp-content/uploads/2022/03/PTH.jpeg"
            alt="Planet Hollywood Thane Front Elevation"
            sx={{ width: "100%", height:"100%", borderRadius: 0 }}
          />
        </Grid>

        {/* Text Section */}
        <Grid item xs={12} md={6}>
          <Typography variant="h4" gutterBottom>
            About Us
          </Typography>
          <Typography variant="body1" color="textSecondary" paragraph>
            Planet Hollywood, Thane City is located in the metropolitan city of Thane, just outside Mumbai.
            The hotel is a vacationers’ delight with breathtaking architecture, landscapes, dramatic sculptures, and artwork.
          </Typography>
          <Typography variant="body1" color="textSecondary" paragraph>
            As you enter the hotel, the neoclassical facade will take you back to ancient Italy and France.
            Each room has been designed with a touch of Hollywood and contemporary interiors that offer a timeless neutral style.
          </Typography>
          <Typography variant="body1" color="textSecondary" paragraph>
            The restaurants, bars, ballroom, and lobby feature a vibrant and energetic look with dramatic patterns, lighting, and artwork.
            The hotel takes pride in being eco-friendly and sustainable. The copper finish highlights across the hotel give it a rich and aesthetic appeal.
          </Typography>
        </Grid>
      </Grid>
    </Container>
  );
};

export default AboutUs;
