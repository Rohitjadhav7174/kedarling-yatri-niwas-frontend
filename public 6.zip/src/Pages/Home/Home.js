import { LayersOutlined } from '@mui/icons-material'
import React from 'react'
import Layout from '../../Components/Layout/Layout'
import HomeSlider from './HomeSlider'
import WhyBookWithUs from './WhyBookWithUs'
import BookDirectSection from './HotelInfo'
import PlanetHollywoodSection from './PlanetHollywoodSection'
import HotelInfo from './HotelInfo'
import Rooms from './Rooms'
import Staycation from './StayCation'
import StaycationComponent from './StaycationComponent'
import CafeHollywood from './CafeHollywood'
import CateringServices from './CateringServices'
import Testimonials from './Testiomonials'
// import WhyBookWithUs'
function Home() {
  return (
    <Layout>
      <HomeSlider/>
      <WhyBookWithUs/>
      <HotelInfo/>
      <Rooms/>
      <Staycation/>
      <StaycationComponent/>
      <CafeHollywood/>
      <CateringServices/>
      <Testimonials/>
    </Layout>
  )
}

export default Home
