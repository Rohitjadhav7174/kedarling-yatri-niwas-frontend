import React from "react";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import Slider1 from "../../Assets/Ph-Hotel-1_11.jpeg";
// import Slider2 from "../../Assets/Ph-Hotel-2.jpeg";
// import Slider3 from "../../Assets/Ph-Hotel-3.jpeg";
import { Box } from "@mui/material";

function HomeSlider() {
  const settings = {
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
    arrows: false,
  };

  return (
    <Slider {...settings} className="home-slider">
      <Box component="img" src={Slider1} alt="Slide 1" sx={{ width: "100%", height: "auto" }} />
      <Box component="img" src={Slider1} alt="Slide 2" sx={{ width: "100%", height: "auto" }} />
      <Box component="img" src={Slider1} alt="Slide 3" sx={{ width: "100%", height: "auto" }} />
    </Slider>
  );
}

export default HomeSlider;
