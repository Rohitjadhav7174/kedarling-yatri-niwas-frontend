import React from "react";
import { Box, Typography, Button } from "@mui/material";

const HotelInfo = () => {
  return (
    <Box sx={{ width: "100%", maxWidth: "1200px", mx: "auto", py: 6 }}>
      
      {/* Book Direct Section (First Section) */}
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
          px: 3,
          mb: 6,
        }}
      >
        {/* Content Section (Left Side) */}
        <Box sx={{ flex: 1, textAlign: { xs: "center", md: "left" } }}>
          <Typography variant="h4" fontWeight="bold" sx={{ mb: 2 }}>
            Book Direct To Save More
          </Typography>
          <Typography variant="body1" sx={{ mb: 3 }}>
            When you book directly with us, you get the best possible rate on your hotel stay.
          </Typography>

          <Button
            variant="contained"
            color="primary"
            href="https://staahmax.staah.net/be/index_be?propertyId=NDgzNA==&individual=true"
            target="_blank"
            sx={{
              fontWeight: "bold",
              px: 4,
              py: 1.5,
              "&:hover": {
                backgroundColor: "#b71c1c",
              },
            }}
          >
            BOOK NOW
          </Button>
        </Box>

        {/* Image Section (Right Side) */}
        <Box sx={{ flex: 1, display: "flex", justifyContent: "center" }}>
          <img
            src="https://planethollywoodthane.com/wp-content/uploads/2023/05/WhatsApp-Image-2023-05-24-at-3.47.48-PM-2.jpeg"
            alt="Book Direct"
            style={{
              width: "100%",
              maxWidth: "500px",
              height: "auto",
            }}
          />
        </Box>
      </Box>

      {/* Planet Hollywood Section (Second Section) */}
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
          px: 3,
        }}
      >
        {/* Image Section (Left Side) */}
        <Box sx={{ flex: 1, display: "flex", justifyContent: "center" }}>
          <img
            src="https://planethollywoodthane.com/wp-content/uploads/2022/10/pht-3.jpg"
            alt="Planet Hollywood"
            style={{
              width: "100%",
              maxWidth: "600px",
              height: "auto",
              // borderRadius: "8px",
            }}
          />
        </Box>

        {/* Content Section (Right Side) */}
        <Box sx={{ flex: 1, textAlign: { xs: "center", md: "left" } }}>
          <Typography
            variant="h2"
            fontWeight="bold"
            sx={{
              color: "#1c1c1d",
              fontSize: { xs: "40px", md: "80px" },
              lineHeight: { xs: "40px", md: "80px" },
              textAlign: "center",
              mb: 3,
            }}
          >
            Planet Hollywood
          </Typography>

          <Typography
            variant="body1"
            sx={{
              color: "#000",
              fontSize: "16px",
              lineHeight: "2",
            }}
          >
            Get a feel of the celebrity life while vacationing at Planet Hollywood, Thane City.
            Experience luxury, fame, and sophistication at the first 5-star hotel in Thane and
            the second of its brand in Asia. The hotel offers an exciting array of top restaurants
            serving the finest cuisine and beverages, all with a unique and glamorous atmosphere.
            Adding to the celebrity lifestyle, the hotel has a rooftop pool and restaurant for you
            to soak in the lavishness.
          </Typography>
        </Box>
      </Box>

      {/* Experience Serenity in the City of Lakes (Now Last Section) */}
      <Box
        sx={{
          display: "flex",
          flexDirection: { xs: "column", md: "row" },
          alignItems: "center",
          justifyContent: "center",
          gap: 4,
          px: 3,
          mt: 6,
        }}
      >
        {/* Content Section (Left Side) */}
        <Box sx={{ flex: 1, textAlign: { xs: "center", md: "left" } }}>
          <Typography
            variant="h1"
            sx={{
              color: "#1c1c1d",
              fontSize: { xs: "40px", md: "80px" },
              lineHeight: { xs: "40px", md: "80px" },
              fontWeight: "normal",
              textAlign: "center",
              mb: 3,
            }}
          >
            Experience Serenity in the City of Lakes
          </Typography>

          <Typography
            variant="body1"
            sx={{
              color: "#000",
              padding: "40px",
              textAlign: "center",
              fontSize: "16px",
              lineHeight: "1.6",
            }}
          >
            Located in the city of lakes, Thane, Planet Hollywood brings to you a serene
            and chic atmosphere with a sense of luxury. Discover an array of experiences -
            dining, spa, fitness, and swimming while you vacation with us or stay over a
            business trip. Leave your worries to us as our event coordinators plan and
            execute your business meetings with ease.
          </Typography>

          <Box sx={{ textAlign: "center", mt: 3 }}>
            <Button
              variant="contained"
              href="https://planethollywoodthane.com/about-us/"
              target="_blank"
              sx={{
                // backgroundColor: "#aa237b",
                color: "#ffffff",
                fontSize: "11px",
                fontWeight: "bold",
                padding: "15px 35px",
                letterSpacing: "2px",
                "&:hover": {
                  backgroundColor: "#8a1a60",
                },
              }}
            >
              ABOUT US
            </Button>
          </Box>
        </Box>

        {/* Image Section (Right Side) */}
        <Box sx={{ flex: 1, display: "flex", justifyContent: "center" }}>
          <img
            src="https://planethollywoodthane.com/wp-content/uploads/2022/05/1-1-1024x963.png"
            alt="Serenity in Thane"
            style={{
              width: "100%",
              maxWidth: "500px",
              height: "auto",
            }}
          />
        </Box>
      </Box>
      
    </Box>
  );
};

export default HotelInfo;
