import React from "react";
import { Container, Grid2, Card, CardMedia, CardContent, Typography, Button, Rating } from "@mui/material";

const rooms = [
  {
    name: "Deluxe",
    image: "https://planethollywoodthane.com/wp-content/uploads/2023/05/Untitled-2-01.jpg",
    description: "Spanning 260 square feet, the Executive Suite includes a wooden floored master bedroom and a marble bathroom.",
    link: "https://planethollywoodthane.com/rooms/deluxe-2/",
    rating: 4.5
  },
  {
    name: "Superior King",
    image: "https://planethollywoodthane.com/wp-content/uploads/2023/05/WhatsApp-Image-2023-05-24-at-3.59.48-PM.jpeg",
    description: "Spanning 294 square feet, the Superior King includes a wooden floored master bedroom and a marble bathroom.",
    link: "https://planethollywoodthane.com/rooms/superior-king/",
    rating: 4.2
  },
  {
    name: "Superior Twin",
    image: "https://planethollywoodthane.com/wp-content/uploads/2023/05/Untitled-3-02-1.jpg",
    description: "Spanning 294 square feet, the superior twin includes a wooden floored master bedroom and a marble bathroom.",
    link: "https://planethollywoodthane.com/rooms/superior-twin/",
    rating: 4.0
  },
  {
    name: "Executive Club",
    image: "https://planethollywoodthane.com/wp-content/uploads/2023/05/WhatsApp-Image-2023-05-24-at-3.47.48-PM-2.jpeg",
    description: "Spanning 294 square feet, the Executive Club includes a wooden floored master bedroom and a marble bathroom.",
    link: "https://staahmax.staah.net/be/index_be?propertyId=NDgzNA==&individual=true",
    rating: 4.7
  },
  {
    name: "Executive Suite",
    image: "https://planethollywoodthane.com/wp-content/uploads/2023/05/WhatsApp-Image-2023-05-24-at-3.46.43-PM-1.jpeg",
    description: "Executive Suite is suitable for business or leisure visitors.",
    link: "https://staahmax.staah.net/be/index_be?propertyId=NDgzNA==&individual=true",
    rating: 4.8
  }
];

const Rooms = () => {
  return (
    <Container>
      <Typography variant="h3" align="center" gutterBottom>
        Rooms
      </Typography>
      <Grid2 container spacing={4}>
        {rooms.map((room, index) => (
          <Grid2  size={{xs:12,sm:6,md:4,xl:4}} key={index}>
            <Card sx={{borderRadius:0}}>
              <CardMedia component="img" height="300" image={room.image} alt={room.name} />
           
              <CardContent>
                <Typography variant="h5">{room.name}</Typography>
                <Rating value={room.rating} precision={0.5} readOnly sx={{ marginTop: 1 }} />
                <Typography variant="body2" color="textSecondary">
                  {room.description}
                </Typography>
               
                <Button
                  variant="contained"
                  color="secondary"
                  href={room.link}
                  target="_blank"
                  sx={{ marginTop: 2 }}
                >
                  Book Now
                </Button>
              </CardContent>
            </Card>
          </Grid2>
        ))}
      </Grid2>
    </Container>
  );
};

export default Rooms;
