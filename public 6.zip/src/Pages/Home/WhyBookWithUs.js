import React from "react";
import { Box, Typography, useMediaQuery, useTheme } from "@mui/material";

const reasons = [
  { icon: "✅", title: "Best Rate", subtitle: "Guarantee" },
  { icon: "🚀", title: "Free Express", subtitle: "Check-Out" },
  { icon: "📅", title: "FREE 48-Hour", subtitle: "Cancellation*" },
  { icon: "💰", title: "Save Now,", subtitle: "Pay Later" },
  { icon: "🎟️", title: "Exclusive Member", subtitle: "Pricing" }
];

const WhyBookWithUs = ({ imageUrl, benefits }) => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("sm"));

  return (
    <Box>
      {/* Booking Image */}
      <Box sx={{ display: "flex", justifyContent: "center", px: 2 }}>
        <Box
          component="img"
          src={imageUrl}
          alt="Booking"
          sx={{
            width: "100%",
            maxWidth: "1287px",
            height: "auto",
            objectFit: "cover"
          }}
        />
      </Box>

      {/* Benefits Section */}
      <Box
        sx={{
          display: "flex",
          flexWrap: isMobile ? "wrap" : "nowrap",
          background: "linear-gradient(180deg, #23242b 0%, #1f2027 100%)",
          color: "#fff",
          minHeight: "80px",
          maxWidth: "1200px",
          alignItems: "center",
          justifyContent: isMobile ? "center" : "space-around",
          padding: "10px",
          boxShadow: "0 10px 20px rgba(0, 0, 0, 0.19), 0 6px 6px rgba(0, 0, 0, 0.23)",
          mx: "auto",
          overflowX: isMobile ? "auto" : "hidden",
          whiteSpace: "nowrap",
          px: 2,
          gap: isMobile ? 2 : 0,
          textAlign: "center"
        }}
      >
        {benefits.map((benefit, index) => (
          <Box
            key={index}
            sx={{
              display: "flex",
              alignItems: "center",
              flexDirection: isMobile ? "column" : "row",
              gap: 1,
              mx: 2,
              minWidth: "120px"
            }}
          >
            <Box sx={{ fontSize: "2rem" }}>{benefit.icon}</Box>
            <Box>
              <Typography variant="body1" fontWeight="bold">
                {benefit.title}
              </Typography>
              <Typography variant="body2">{benefit.subtitle}</Typography>
            </Box>
          </Box>
        ))}
      </Box>
    </Box>
  );
};

// Default Props
WhyBookWithUs.defaultProps = {
  imageUrl: "https://planethollywoodthane.com/wp-content/uploads/2023/05/booking.png",
  benefits: reasons
};

export default WhyBookWithUs;